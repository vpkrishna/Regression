 library(plyr)
 library(stringr)
 library(granova)
 library(rgl) 

 bestbuyled<-read.csv('C:/Prasanna Krishna/Prasanna Krishna/MS/452/Project/Modelandprice/Walmart/BestBuye.csv',header=TRUE)
 bestbuyled<- bestbuyled[,2:3]
 bestbuyled=rename( bestbuyled, c("X1Models"="X", "X2DP"="X0"))
 bestbuyled$company<-"BestBuy"


 Walmartled<-read.csv('C:/Prasanna Krishna/Prasanna Krishna/MS/452/Project/Modelandprice/Walmart/Walmarte.csv',header=TRUE)
 Walmartled<- Walmartled[,2:3]
 Walmartled=rename( Walmartled, c("X1Models"="X", "X2DP"="X0"))
 Walmartled$company<-"Walmart"
 Walmartled$X0<-gsub("[,$]", "", Walmartled$X0)
 Walmartled$X0<-as.numeric(Walmartled$X0)



 
 Amazonled<-read.csv('C:/Prasanna Krishna/Prasanna Krishna/MS/452/Project/Modelandprice/Walmart/Amazone.csv',header=TRUE,stringsAsFactors=FALSE)
 Amazonled<-Amazonled[,2:3]
 Amazonled=rename(Amazonled, c("X1Models"="X", "X2DP"="X0"))


 Amazonled <- subset(Amazonled, X0 !="No Discount",)
 Amazonled$X0<-gsub("[,$]", "", Amazonled$X0)
 Amazonled$X0<-as.numeric(Amazonled$X0)
 Amazonled$company<-"Amazon"


 Annova_dataset<-rbind(bestbuyled,Amazonled,Walmartled)
 Annova_dataset<-Annova_dataset[,c(2,3)]
 oneway.test(Annova_dataset$X0 ~Annova_dataset$company)
 bartlett.test(Annova_dataset$X0 ~Annova_dataset$company)
 kruskal.test(Annova_dataset$X0 ~Annova_dataset$company)

 mean(bestbuyled$X0)
 mean(Amazonled$X0)
 mean(Walmartled$X0)
 
 Annova_dataset<-data.frame(Bestbuy=bestbuyled[,2],Amazon=Amazonled[,2],Walmart=Walmartled[,2])
 granova.1w(Annova_dataset)


*******************************4K ***********************

 bestbuyled<-read.csv('C:/Prasanna Krishna/Prasanna Krishna/MS/452/Project/Modelandprice/Walmart/BestBuy4ke.csv',header=TRUE)
 bestbuyled<- bestbuyled[,2:3]
 bestbuyled=rename( bestbuyled, c("X1Models"="X", "X2DP"="X0"))
 bestbuyled$company<-"BestBuy"


 


 
 Amazonled<-read.csv('C:/Prasanna Krishna/Prasanna Krishna/MS/452/Project/Modelandprice/Walmart/Amazon4ke.csv',header=TRUE,stringsAsFactors=FALSE)
 Amazonled<-Amazonled[,2:3]
 Amazonled=rename(Amazonled, c("X1Models"="X", "X2DP"="X0"))


 Amazonled <- subset(Amazonled, X0 !="No Discount",)
 Amazonled$X0<-gsub("[,$]", "", Amazonled$X0)
 Amazonled$X0<-as.numeric(Amazonled$X0)
 Amazonled$company<-"Amazon"


 Annova_dataset<-rbind(bestbuyled,Amazonled)
 Annova_dataset<-Annova_dataset[,c(2,3)]
 oneway.test(Annova_dataset$X0 ~Annova_dataset$company)
 bartlett.test(Annova_dataset$X0 ~Annova_dataset$company)
 kruskal.test(Annova_dataset$X0 ~Annova_dataset$company)

 mean(bestbuyled$X0)
 mean(Amazonled$X0)
 
 
 Annova_dataset<-data.frame(Bestbuy=bestbuyled[,2],Amazon=Amazonled[,2])
 granova.1w(Annova_dataset)





 ###This means we cannot reject the null hypothesis that the variance is the same for all treatment groups. 
